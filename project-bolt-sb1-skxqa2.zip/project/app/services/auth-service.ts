import { Observable } from '@nativescript/core';

export class AuthService extends Observable {
  private static instance: AuthService;
  private _currentUser: any = null;

  static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService();
    }
    return AuthService.instance;
  }

  login(email: string, password: string): Promise<boolean> {
    // TODO: Implement actual authentication
    return new Promise((resolve) => {
      this._currentUser = { email, role: 'student' };
      resolve(true);
    });
  }

  logout(): void {
    this._currentUser = null;
  }

  get isLoggedIn(): boolean {
    return this._currentUser !== null;
  }

  get currentUser(): any {
    return this._currentUser;
  }
}