import { Application } from '@nativescript/core';

Application.run({ moduleName: 'views/login/login-page' });