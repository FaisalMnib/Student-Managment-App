import { Observable } from '@nativescript/core';
import { AuthService } from '../../services/auth-service';
import { navigate } from '@nativescript/core/ui/frame';

export class LoginViewModel extends Observable {
  private _email: string = '';
  private _password: string = '';
  private _errorMessage: string = '';

  constructor() {
    super();
  }

  get email(): string {
    return this._email;
  }

  set email(value: string) {
    if (this._email !== value) {
      this._email = value;
      this.notifyPropertyChange('email', value);
    }
  }

  get password(): string {
    return this._password;
  }

  set password(value: string) {
    if (this._password !== value) {
      this._password = value;
      this.notifyPropertyChange('password', value);
    }
  }

  get errorMessage(): string {
    return this._errorMessage;
  }

  set errorMessage(value: string) {
    if (this._errorMessage !== value) {
      this._errorMessage = value;
      this.notifyPropertyChange('errorMessage', value);
    }
  }

  async onLogin() {
    if (!this.email || !this.password) {
      this.errorMessage = 'Please enter both email and password';
      return;
    }

    try {
      const success = await AuthService.getInstance().login(this.email, this.password);
      if (success) {
        navigate({
          moduleName: 'views/dashboard/dashboard-page',
          clearHistory: true
        });
      } else {
        this.errorMessage = 'Invalid credentials';
      }
    } catch (error) {
      this.errorMessage = 'Login failed. Please try again.';
    }
  }
}