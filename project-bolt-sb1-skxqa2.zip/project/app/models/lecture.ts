export interface Lecture {
  id: string;
  title: string;
  date: Date;
  time: string;
  meetingLink: string;
  course: string;
}