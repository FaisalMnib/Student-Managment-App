export interface Student {
  id: string;
  name: string;
  college: string;
  class: string;
  course: string;
  whatsapp: string;
  email: string;
  feeHistory: FeePayment[];
}

export interface FeePayment {
  month: string;
  amount: number;
  paid: boolean;
  paidDate?: Date;
}